def shortest_path(start_cell, goal_cell, grid, is_blocked):
    if start_cell is goal_cell:
        return []

    vertices = []
    for cell in grid:
        if not is_blocked(cell):
            vertices.append(cell)

    dist = {}
    prev = {}
    infinito = float("inf")

    for v in vertices:
        dist[v] = infinito
        prev[v] = None

    dist[start_cell] = 0.0

    Q = set(vertices)
    S = set()

    while len(Q) > 0:
        v = min(Q, key=lambda c: dist[c])

        Q.remove(v)
        S.add(v)

        if v is goal_cell:
            break

        if dist[v] == infinito:
            break

        for u in v.neighborhood:
            if is_blocked(u):
                continue
            if u in S:
                continue
            if u not in Q:
                continue
            alt = dist[v] + 1.0
            if alt < dist[u]:
                dist[u] = alt
                prev[u] = v

    if dist.get(goal_cell, infinito) == infinito:
        return None

    path = []
    current = goal_cell
    while current is not None and current is not start_cell:
        path.append(current)
        current = prev.get(current)

    if current is None:
        return None

    path.reverse()
    return path