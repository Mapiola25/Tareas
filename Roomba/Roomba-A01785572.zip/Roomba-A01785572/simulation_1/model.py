import math
from mesa import Model
from mesa.datacollection import DataCollector
from mesa.discrete_space import OrthogonalVonNeumannGrid
from mesa.experimental.devs import ABMSimulator
from .agent import Garbage, Obstacle, Charger, Roomba

def compute_clean_fraction(model):
    total_cells = model.width * model.height
    num_obstacles = len(model.agents_by_type[Obstacle])
    cleanable_cells = total_cells - num_obstacles
    if cleanable_cells <= 0:
        return 1.0

    dirty_garbage = []
    for g in model.agents_by_type[Garbage]:
        if not getattr(g, "cleaned", False):
            dirty_garbage.append(g)

    num_dirty_cells = len(dirty_garbage)
    value = (cleanable_cells - num_dirty_cells) / float(cleanable_cells)
    if value < 0.0:
        value = 0.0
    return value

def compute_clean_percentage(model):
    return 100.0 * compute_clean_fraction(model)

def compute_avg_battery(model):
    roombas = model.agents_by_type[Roomba]
    roombas_list = [r for r in roombas]
    if len(roombas_list) == 0:
        return 0.0
    total = 0.0
    for r in roombas_list:
        total += r.battery
    return total / float(len(roombas_list))

def compute_total_moves(model):
    if hasattr(model, "total_moves"):
        return model.total_moves
    return 0

def compute_dirty_percentage(model):
    return 100.0 - compute_clean_percentage(model)

class VacuumModel(Model):
    def __init__(
        self,
        width=10,
        height=10,
        num_roombas=1,
        dirt_percentage=30.0,
        obstacle_percentage=10.0,
        max_steps=500,
        seed=None,
        simulator=None,
    ):
        Model.__init__(self)

        self.width = width
        self.height = height
        self.num_roombas = num_roombas
        self.max_steps = max_steps

        self.step_count = 0
        self.total_moves = 0
        self.time_all_clean = None

        if dirt_percentage > 1.0:
            self.dirt_fraction = dirt_percentage / 100.0
        else:
            self.dirt_fraction = dirt_percentage

        if obstacle_percentage > 1.0:
            self.obstacle_fraction = obstacle_percentage / 100.0
        else:
            self.obstacle_fraction = obstacle_percentage

        if simulator is None:
            simulator = ABMSimulator()
        self.simulator = simulator
        self.simulator.setup(self)

        self.grid = OrthogonalVonNeumannGrid(
            [self.height, self.width],
            torus=False,
            capacity=math.inf,
            random=self.random,
        )

        self.charging_cell = None
        self.charger_cells = []

        self._create_environment()
        self._create_roombas()

        self.datacollector = DataCollector(
            model_reporters={
                "CleanFraction": compute_clean_fraction,
                "Limpio": compute_clean_percentage,
                "Suciedad": compute_dirty_percentage,
                "Bateria": compute_avg_battery,
                "TotalMoves": compute_total_moves,
                "Steps": lambda m: m.step_count,
            }
        )

        self.running = True
        self.datacollector.collect(self)

    def _create_environment(self):
        if self.num_roombas == 1:
            self.charging_cell = None
            for cell in self.grid:
                if cell.coordinate == (0, 0):
                    self.charging_cell = cell
                    break
            if self.charging_cell is None:
                self.charging_cell = next(iter(self.grid))
            Charger(self, self.charging_cell)
            self.charger_cells = [self.charging_cell]

            all_cells = []
            for c in self.grid:
                if c is not self.charging_cell:
                    all_cells.append(c)
        else:
            self.charging_cell = None
            self.charger_cells = []
            all_cells = []
            for c in self.grid:
                all_cells.append(c)

        max_obstacles = len(all_cells)
        num_obstacles = int(self.obstacle_fraction * max_obstacles)
        if num_obstacles < 0:
            num_obstacles = 0
        if num_obstacles > max_obstacles:
            num_obstacles = max_obstacles

        obstacle_cells = []
        if num_obstacles > 0:
            obstacle_cells = self.random.sample(all_cells, num_obstacles)
            for cell in obstacle_cells:
                Obstacle(self, cell)

        def has_obstacle(cell):
            for a in cell.agents:
                if isinstance(a, Obstacle):
                    return True
            return False

        dirt_candidates = []
        for c in all_cells:
            if not has_obstacle(c):
                dirt_candidates.append(c)

        max_dirt = len(dirt_candidates)
        num_dirt = int(self.dirt_fraction * max_dirt)
        if num_dirt < 0:
            num_dirt = 0
        if num_dirt > max_dirt:
            num_dirt = max_dirt

        if num_dirt > 0:
            dirt_cells = self.random.sample(dirt_candidates, num_dirt)
            for cell in dirt_cells:
                Garbage(self, cell)

    def _create_roombas(self):
        def has_obstacle(cell):
            for a in cell.agents:
                if isinstance(a, Obstacle):
                    return True
            return False
        
        if self.num_roombas <= 1:
            if len(self.charger_cells) > 0:
                start_cell = self.charger_cells[0]
            else:
                start_cell = next(iter(self.grid))
                Charger(self, start_cell)
                self.charger_cells = [start_cell]
                self.charging_cell = start_cell
            Roomba(self, start_cell, battery=100)
        else:
            available_cells = []
            for c in self.grid:
                if not has_obstacle(c):
                    available_cells.append(c)
            used_cells = set()
            for c in self.charger_cells:
                used_cells.add(c)
            count = 0
            while count < self.num_roombas:
                candidates = []
                for c in available_cells:
                    if c not in used_cells:
                        candidates.append(c)
                if len(candidates) == 0:
                    break
                cell = self.random.choice(candidates)
                used_cells.add(cell)
                Charger(self, cell)
                self.charger_cells.append(cell)
                Roomba(self, cell, battery=100)
                count += 1
            if len(self.charger_cells) > 0 and self.charging_cell is None:
                self.charging_cell = self.charger_cells[0]

    def all_cells_clean(self):
        for g in self.agents_by_type[Garbage]:
            if not getattr(g, "cleaned", False):
                return False
        return True

    def step(self):
        self.step_count += 1
        self.agents_by_type[Roomba].shuffle_do("step")
        self.datacollector.collect(self)
        if self.all_cells_clean() and self.time_all_clean is None:
            self.time_all_clean = self.step_count
        if self.all_cells_clean() or self.step_count >= self.max_steps:
            self.running = False
        else:
            self.running = True