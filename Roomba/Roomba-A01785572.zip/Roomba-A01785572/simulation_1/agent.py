from mesa.discrete_space import CellAgent, FixedAgent
from .dijkstra import shortest_path

class Garbage(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell
        self.cleaned = False

    def step(self):
        pass

class Obstacle(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell

    def step(self):
        pass

class Charger(FixedAgent):
    def __init__(self, model, cell):
        super().__init__(model)
        self.cell = cell

    def step(self):
        pass

class Roomba(CellAgent):
    def __init__(self, model, cell, battery=100):
        super().__init__(model)
        self.cell = cell
        self.battery = battery
        self.moves = 0
        self.going_to_charge = False
        self.last_cell = None 

    def _celda_tiene_obstaculo(self, celda):
        for a in celda.agents:
            if isinstance(a, Obstacle):
                return True
        return False

    def _mover_a_celda(self, nueva_celda):
        if nueva_celda is self.cell:
            return
        self.last_cell = self.cell
        self.cell = nueva_celda
        self.moves += 1
        self.model.total_moves += 1

    @staticmethod
    def _distancia_manhattan_celdas(celda_a, celda_b):
        ax, ay = celda_a.coordinate
        bx, by = celda_b.coordinate
        return abs(ax - bx) + abs(ay - by)

    def _mover_hacia_objetivo(self, celda_objetivo):
        def esta_bloqueada(celda):
            return self._celda_tiene_obstaculo(celda)

        camino = shortest_path(
            start_cell=self.cell,
            goal_cell=celda_objetivo,
            grid=self.model.grid,
            is_blocked=esta_bloqueada,
        )
        if not camino:
            return False
        siguiente = camino[0]
        self._mover_a_celda(siguiente)
        return True

    def _vecinos_libres(self):
        vecinos_libres = []
        for c in self.cell.neighborhood:
            if not self._celda_tiene_obstaculo(c):
                vecinos_libres.append(c)
        return vecinos_libres

    def _elegir_vecino_simple(self, vecinos_libres):
        if len(vecinos_libres) == 0:
            return None

        vecinos_con_basura = []
        for c in vecinos_libres:
            hay_basura = False
            for a in c.agents:
                if isinstance(a, Garbage) and not a.cleaned:
                    hay_basura = True
                    break
            if hay_basura:
                vecinos_con_basura.append(c)

        candidatos = vecinos_libres
        if len(vecinos_con_basura) > 0:
            candidatos = vecinos_con_basura

        if self.last_cell is not None:
            candidatos_sin_regresar = []
            for c in candidatos:
                if c is not self.last_cell:
                    candidatos_sin_regresar.append(c)
            if len(candidatos_sin_regresar) > 0:
                candidatos = candidatos_sin_regresar

        return self.random.choice(candidatos)

    def step(self):
        if self.battery <= 0:
            return

        celdas_cargador = []
        for c in self.model.charger_cells:
            celdas_cargador.append(c)
        if len(celdas_cargador) == 0 and self.model.charging_cell is not None:
            celdas_cargador.append(self.model.charging_cell)

        celda_cargador = None
        dist_cargador = None
        for c in celdas_cargador:
            d = self._distancia_manhattan_celdas(self.cell, c)
            if dist_cargador is None or d < dist_cargador:
                dist_cargador = d
                celda_cargador = c

        if self.going_to_charge and celda_cargador is not None:
            if self.cell is not celda_cargador:
                se_movio = self._mover_hacia_objetivo(celda_cargador)
                if se_movio:
                    self.battery = max(self.battery - 1, 0)
                return
            else:
                if self.battery < 80:
                    otros_roombas = []
                    for a in self.cell.agents:
                        if isinstance(a, Roomba) and a is not self:
                            otros_roombas.append(a)
                    if len(otros_roombas) == 0:
                        self.battery = min(self.battery + 5, 100)
                    return
                else:
                    self.going_to_charge = False

        did_action = False

        basura_en_celda = []
        for a in self.cell.agents:
            if isinstance(a, Garbage) and not a.cleaned:
                basura_en_celda.append(a)

        if basura_en_celda:
            for g in basura_en_celda:
                g.cleaned = True
            did_action = True

        if (
            celda_cargador is not None
            and self.cell is not celda_cargador
            and dist_cargador is not None
        ):
            margen = 5
            if self.battery <= dist_cargador + margen:
                self.going_to_charge = True
                if did_action:
                    self.battery = max(self.battery - 1, 0)
                return

        vecinos_libres = self._vecinos_libres()
        if len(vecinos_libres) > 0:
            siguiente = self._elegir_vecino_simple(vecinos_libres)
            if siguiente is not None:
                self._mover_a_celda(siguiente)
                did_action = True

        if did_action:
            self.battery = max(self.battery - 1, 0)