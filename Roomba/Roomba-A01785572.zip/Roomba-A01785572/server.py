from mesa.experimental.devs import ABMSimulator
from mesa.visualization import (
    Slider,
    SolaraViz,
    SpaceRenderer,
    make_plot_component,
)
from mesa.visualization.components import AgentPortrayalStyle
from simulation_1.agent import Garbage, Obstacle, Charger, Roomba
from simulation_1.model import VacuumModel

def vacuum_portrayal(agent):
    if agent is None:
        return

    if isinstance(agent, Roomba):
        return AgentPortrayalStyle(
            size=12,
            marker="o",
            zorder=3,
            color="tab:red",
        )

    if isinstance(agent, Charger):
        return AgentPortrayalStyle(
            size=10,
            marker="s",
            zorder=2,
            color="tab:green",
        )

    if isinstance(agent, Obstacle):
        return AgentPortrayalStyle(
            size=10,
            marker="s",
            zorder=1,
            color="black",
        )

    if isinstance(agent, Garbage):
        if agent.cleaned:
            return AgentPortrayalStyle(
                size=1,
                marker="s",
                zorder=0,
                color="white",
            )
        else:
            return AgentPortrayalStyle(
                size=8,
                marker="s",
                zorder=1,
                color="tab:blue",
            )

def post_process_space(ax):
    ax.set_aspect("equal")

    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()

    cols = int(round(x_max - x_min))
    rows = int(round(y_max - y_min))

    xticks = []
    for i in range(cols + 1):
        xticks.append(x_min + i)

    yticks = []
    for i in range(rows + 1):
        yticks.append(y_min + i)

    ax.set_xticks(xticks)
    ax.set_yticks(yticks)

    ax.grid(which="both", linewidth=0.5)
    ax.tick_params(
        bottom=False,
        left=False,
        labelbottom=False,
        labelleft=False,
    )

def post_process_lines(ax):
    ax.legend(loc="center left", bbox_to_anchor=(1, 0.9))

lineplot_component = make_plot_component(
    {
        "Limpio": "tab:green",
        "Suciedad": "tab:orange",
        "Bateria": "tab:red",
        "Steps": "tab:blue",
    },
    post_process=post_process_lines,
)

model_params = {
    "seed": {
        "type": "InputText",
        "value": 42,
        "label": "Seed",
    },
    "width": Slider("Width", 10, 5, 50, 1),
    "height": Slider("Height", 10, 5, 50, 1),
    "num_roombas": Slider("Roombas", 1, 1, 5, 1),
    "dirt_percentage": Slider("Dirt %", 30, 0, 100, 5),
    "obstacle_percentage": Slider("Obstacles %", 10, 0, 80, 5),
    "max_steps": Slider("Steps", 500, 50, 3000, 50),
}

simulator = ABMSimulator()
model = VacuumModel(simulator=simulator)

renderer = SpaceRenderer(
    model,
    backend="matplotlib",
)
renderer.draw_agents(vacuum_portrayal)
renderer.post_process = post_process_space

page = SolaraViz(
    model,
    renderer,
    components=[lineplot_component],
    model_params=model_params,
    name="Roomba",
    simulator=simulator,
)
