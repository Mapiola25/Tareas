'use strict';

import * as twgl from 'twgl-base.js';
import { M3 } from './libs/2d_lib.js';
import GUI from 'lil-gui';

function circleFace(radius = 120, segments = 48) {
    const pos = [0, 0];
    const indices = [];
    for (let i = 0; i <= segments; i++) {
        const a = (i / segments) * Math.PI * 2;
        pos.push(Math.cos(a) * radius, Math.sin(a) * radius);
        if (i > 0) indices.push(0, i, i + 1);
    }
    return {
        a_position: { numComponents: 2, data: pos },
        indices: { numComponents: 3, data: indices }
    };
}

function diamond(size) {
    return {
        a_position: {
            numComponents: 2,
            data: [
                size, 0,
                0, size,
                -size, 0,
                0, -size
            ]
        },
        indices: {
            numComponents: 3,
            data: [
                0, 1, 2,
                2, 3, 0
            ]
        }
    };
}

const objects = {
    face: {
        transforms: {
            t: { x: 310, y: 300 },
            rr: { z: 0 },
            s: { x: 1, y: 1 }
        },
        color: [1, 1, 0, 1]
    },
    pivot: {
        transforms: {
            t: { x: 450, y: 300 },
            rr: { z: 0 },
            s: { x: 1, y: 1 }
        },
        color: [0.5, 0.5, 0.5, 1]
    },
    leftEye: {
        offset: { x: -50, y: -40 },
        color: [0, 0, 0, 1]
    },
    rightEye: {
        offset: { x: 50, y: -40 },
        color: [0, 0, 0, 1]
    }
};

const vsGLSL = `#version 300 es
in vec2 a_position;

uniform vec2 u_resolution;
uniform mat3 u_transforms;

void main() {
    vec2 pos = (u_transforms * vec3(a_position, 1)).xy;
    vec2 zeroToOne = pos / u_resolution;
    vec2 clip = zeroToOne * 2.0 - 1.0;
    gl_Position = vec4(clip * vec2(1, -1), 0, 1);
}
`;

const fsGLSL = `#version 300 es
precision highp float;

uniform vec4 u_color;

out vec4 outColor;

void main() {
    outColor = u_color;
}
`;

let faceBuffer, faceVao;
let pivotBuffer, pivotVao;
let eyeBuffer, eyeVao;

function main() {
    const canvas = document.querySelector("canvas");
    const gl = canvas.getContext("webgl2");
    twgl.resizeCanvasToDisplaySize(gl.canvas);
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    setupUI(gl);

    const programInfo = twgl.createProgramInfo(gl, [vsGLSL, fsGLSL]);

    faceBuffer = twgl.createBufferInfoFromArrays(gl, circleFace());
    faceVao = twgl.createVAOFromBufferInfo(gl, programInfo, faceBuffer);

    pivotBuffer = twgl.createBufferInfoFromArrays(gl, diamond(12));
    pivotVao = twgl.createVAOFromBufferInfo(gl, programInfo, pivotBuffer);

    eyeBuffer = twgl.createBufferInfoFromArrays(gl, diamond(20));
    eyeVao = twgl.createVAOFromBufferInfo(gl, programInfo, eyeBuffer);

    drawScene(gl, programInfo);
}

function drawShape(gl, vao, bufferInfo, programInfo, transform, color) {
    let uniforms = {
        u_resolution: [gl.canvas.width, gl.canvas.height],
        u_transforms: transform,
        u_color: color
    };
    gl.useProgram(programInfo.program);
    twgl.setUniforms(programInfo, uniforms);
    gl.bindVertexArray(vao);
    twgl.drawBufferInfo(gl, bufferInfo);
}

function drawScene(gl, programInfo) {

    gl.clearColor(1, 1, 1, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    let faceMat = rotateAroundPivot(objects.face.transforms, objects.pivot.transforms);

    drawShape(gl, faceVao, faceBuffer, programInfo, faceMat, objects.face.color);

    drawEye(gl, programInfo, objects.leftEye.offset, faceMat, objects.leftEye.color);
    drawEye(gl, programInfo, objects.rightEye.offset, faceMat, objects.rightEye.color);

    let pivotMat = computeMatrix(objects.pivot.transforms);
    drawShape(gl, pivotVao, pivotBuffer, programInfo, pivotMat, objects.pivot.color);

    requestAnimationFrame(() => drawScene(gl, programInfo));
}

function drawEye(gl, programInfo, offset, baseMatrix, color) {
    let E = M3.multiply(M3.translation([offset.x, offset.y]), baseMatrix);
    drawShape(gl, eyeVao, eyeBuffer, programInfo, E, color);
}

function computeMatrix(t) {
    let M = M3.identity();
    M = M3.multiply(M3.scale([t.s.x, t.s.y]), M);
    M = M3.multiply(M3.rotation(t.rr.z), M);
    M = M3.multiply(M3.translation([t.t.x, t.t.y]), M);
    return M;
}

function rotateAroundPivot(face, pivot) {
    let M = M3.identity();
    M = M3.multiply(M3.translation([face.t.x, face.t.y]), M);
    M = M3.multiply(M3.translation([-pivot.t.x, -pivot.t.y]), M);
    M = M3.multiply(M3.rotation(-face.rr.z), M);
    M = M3.multiply(M3.translation([pivot.t.x, pivot.t.y]), M);
    return M;
}

function setupUI(gl) {
    const gui = new GUI();

    const f1 = gui.addFolder("Face");
    f1.add(objects.face.transforms.t, "x", 0, gl.canvas.width);
    f1.add(objects.face.transforms.t, "y", 0, gl.canvas.height);
    f1.add(objects.face.transforms.rr, "z", -3.14, 3.14);

    const f2 = gui.addFolder("Pivot");
    f2.add(objects.pivot.transforms.t, "x", 0, gl.canvas.width);
    f2.add(objects.pivot.transforms.t, "y", 0, gl.canvas.height);
}

main();